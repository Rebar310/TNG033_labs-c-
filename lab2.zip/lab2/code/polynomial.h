/*************************
 * Class Polynomial       *
 * TNG033: Lab 2          *
 **************************/

#pragma once

#include <iostream>

#include "expression.h"

class Polynomial : public Expression {
    // ADD CODE
};

/*
 * std::vector should be used to store polinomial's coefficients
 */